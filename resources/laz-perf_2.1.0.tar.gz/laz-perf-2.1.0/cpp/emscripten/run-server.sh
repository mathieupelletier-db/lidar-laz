#!/bin/sh
#

exec python -m http.server
